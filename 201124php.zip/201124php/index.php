<?php
include 'functions.php';

$products = load_products_from_ini('products.ini');
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .product-card {
            border: 1px solid #ccc;
            padding: 20px;
            margin: 20px;
            width: 300px;
            display: inline-block;
            vertical-align: top;
        }
        .product-card h2 {
            margin: 0;
            font-size: 1.5em;
        }
        .product-card p {
            margin: 5px 0;
        }
    </style>
</head>
<body>
    <h1>Карточки товаров</h1>
    
    <?php
    display_all_products($products);
    ?>
</body>
</html>