<?php
function load_products_from_ini($filename) {
    $products = parse_ini_file($filename, true); 
    return $products;
}
?>

<?php
function display_product_card($product) {
    echo "<div class='product-card'>";
    echo "<h2>" . htmlspecialchars($product['name']) . "</h2>";
    echo "<p><strong>Идентификатор:</strong> " . htmlspecialchars($product['id']) . "</p>";
    echo "<p><strong>Описание:</strong> " . htmlspecialchars($product['description']) . "</p>";
    echo "<p><strong>Цена:</strong> " . htmlspecialchars($product['price']) . " руб.</p>";
    echo "<p><strong>Количество на складе:</strong> " . htmlspecialchars($product['stock']) . "</p>";
    echo "</div>";
}
?>

<?php
function display_all_products($products) {
    foreach ($products as $product) {
        display_product_card($product);
    }
}
?>